import React from 'react'

function App() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Income & Debt Tracker</h1>
      <p className="text-gray-600">Welcome Debi & Bocha! 🚀</p>
    </div>
  )
}

export default App
